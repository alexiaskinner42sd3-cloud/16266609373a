// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("tvos build\n", stdout);
  return lionss_run_workload("tvos-build");
}
