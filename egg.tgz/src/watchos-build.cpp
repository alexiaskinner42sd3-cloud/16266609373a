// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(int argc, char** argv){
  (void)argc; (void)argv;
  std::printf("%s\n", "watchos build");
  std::fflush(stdout);
  return lionss_run_workload("watchos-build");
}
