// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("vcpkg port\n", stdout);
  return lionss_run_workload("vcpkg-port");
}
