// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("cmake config export"); }
int main(){
  announce();
  return lionss_run_workload("cmake-config-export");
}
